import React, {useState, useEffect } from 'react';
import Navbar from "./components/Navbar";
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import { Container, Dimmer, Loader } from 'semantic-ui-react'
import Planets from './components/Planets';
import Home from './components/Home';
import People from './components/People';
import Pickles from './components/Person';

let homeBoy = "Tatooine";
let planetArray = [];
let filmy1 = "I like this name...farts";
let filmy2 = "I like this name...farts";
let filmy3 = "I like this name...farts";
let filmy4 = "I like this name...farts";
let filmy5 = "I like this name...farts";
let filmy6 = "I like this name...farts";
let filmy7 = "I like this name...farts";
let person1 = "I like this name...farts";
let person2 = "I like this name...farts";
let person3 = "I like this name...farts";
let person4 = "I like this name...farts";
let person5 = "I like this name...farts";
let person6 = "I like this name...farts";
let person7 = "I like this name...farts";
let hmm = "farts";
let someGuy = "farts";
let theURL;
let peopleBool = true;
function App() {
  //let image_url = "https://lh3.googleusercontent.com/proxy/nTnZE7Ce__oQ3uCry05xpe4o5ZgPgtEYjAYcparS0AIbNxdoHvMM0ZjNx9HzzMpWaUzRoUYRKPQFDT8UNK8LYXppglpG3EdjWK7WLKfmDQ";
  let image_url = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhMTExAWFhIXFRkVFhYYEhcXGBUaFxUYFhUYGBoYHiohGBolGxgXITEhJSorLi4vGiszODMsNygtLisBCgoKDg0OGxAQGi0lHyUtLS01LS0tLS0tLS0tLS8tLS0tMC0tKy0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLy0tLf/AABEIAKgBLAMBIgACEQEDEQH/xAAaAAEBAQEBAQEAAAAAAAAAAAAAAwIBBAUH/8QAMRAAAgICAQMDAwMDBAMBAAAAAQIAERIhAwQxQSJRYROBkQUycUKh8CNiscFS0eEU/8QAFwEBAQEBAAAAAAAAAAAAAAAAAAECA//EACERAQEBAAICAwADAQAAAAAAAAABEQIhMUESUWEioeED/9oADAMBAAIRAxEAPwD8NiIgJXl5yyopCgKCAQoBNkt6iBbHfc+NSUSyhESnLyAhQEAKiiRdvsm2s1e61WgPNmME5o8hoLZxBJAvQJqyB7mh+BMxIET2fp/T8Tjl+pzfTK8ZZPQW+o4Irj1+2wT6jrU8c1eNkl+wlBwsVL4nAEKWo0CQSAT2BIB18GTmxyGitnEkEi9Ei6JHuLP5kmexiJTn4GQgMpUlQwsVasAykfBBBk4swIierp+HiPHys3KV5Fx+mmFjks01tfoob7G5ePH5DyxETIREQOhTRNaHf4nJ0GcgIidViDYNEdoHIiICIiAiIgIiICV4uHIOclGIBotRa2C0o8nd17AmcHMcSmsSQx0LtQQN9/6jr/1Ms90NaFdgPJO67nfc/wDU10MxETIREQEREBERAREQETSgUbJy1QrR97N68eD9p7E/SuU8B6hVy41NOVNnj2oUuB+wMWoE96PtNTjb4HlThJDMKpQCfUAdmhQJs7PiTiJkIiIFOFQzAMwUE0WIJA+aAJ/E4OQgFQTiasXo12seaszES6EREg6DOSvU9Q3IxdzbGrNAdgAND4ElLQiIkFHQAKQwJN2KNrRoA2KN99XJxEBPSeLjHHl9W+Q1SBDQ2wObGqNBSMQ13sip5pvl5CzFjVk2aAUbPgAUB8Ca42QYie39YbiPM/0QBxaxoMP6RenJPe+5nik5TLYEREgREQEREBETZYYgY+qzZvuKFCvFUd+b+IGIiICIiBvl4ypoijQP2YBgfuCDMREBERAREQE0GIsXo9/md4+MtdAmhZoXQ9/4mSKlls7gTk6DOSBE9XX/AEfR9Ecg/wBNfqZlT/qbzxxH7O1XueWa5ccuDta7/aciX4uoA43T6aksVIcg5JjdhTdUb3YPYSSS+RCIiQJoOaIvRIJHyLA/5P5mYgIiIHo6rhKjjtQMkyBDXkCzCzv0nVVrtfmR4+QqbUkGiLBrTAhh/BBI+8zEtvfQrx8DMrsKpAC1sAdkKKBNts+JKV6Xp35HXjRSzuwVVAsszGgAPJJmORCpKkUQSCD3BGiDLZ1uDM1ycZU0RugfyLH9jMyq9O5Q8gU4BgpbwGYMVH8kK34kkt8CUREgREQEREBERAREQEREBERAr07KDbqWWjoNjsggG6PY0fmpKIl0IiJAnZyVHUNgePWJYMfSLsAgbq6onV1LP0SlDhRrIHVDRv8A8rOq320f+508PoD5LtiuN+oUAciP/HdX8SUeAiIkCdUX/ntuU6bp35GCcaM7nsqqWJ1egNmSlz2LdJhmPqZYecKyOtAXobre69j2kmqzXbxZszkRvQ6R2137fPib5WUhcVIIWmJa8myJsa9IogVvtfmYLE1vtofG719yZ68OPjdg9cowOJ43KgMyWptls4sdihdEX5l4zR5uIAkZGh5IF19vMxE6B/aZHUA8mte178CGUjuK0Dv2IsH8blOk4PqOqZKuRAydsVW/LHwPmTSrF3je6715q/MudaOAzk3w45LneNjLEAmr3V6upkx6HIlODHIZ3j5xq/tepOQa5OMqaYEH2Io72O8zN8vIzG2Ysfckk6FDZ+JiKEREBERAREQEREBERAREQETa8rAMAxAashejRsX77mICImhxkgsAcRQJrQu6s+Lo/iBmaVyAQCQCKO+4sGj77AP2mYgb5FAOmB0DYvyASNgbHY+Nasbnen4GdgiKzOxpVUFmJ9gBsmTlR1LgqQxBQUpBorstojtsk/eWZ7Gun6Tk5A5RCwRc3oXioIUsfYWwH3kJ25yLnodBqV4eoxV1wU5gCytlaYNaH+k6r+CZGIlsCV6fp25CQi2QrMR/tRSzH7KCZKV5CmKY5ZUc7Iq8jWNeMa7+YmexKejpOl+pn60TFGcZmssRZVdbYjsPP4nnluLlwdSMXCtYBFo1Hyp7g12PiXjm9jHCgZgCwUH+o3Q/nEE/gTiAbska1QvfjzofMv1lEhlRFDAEKjEhatTeRJBJUmifOtVI8vHjVkXXbyNkUfY6izBiV4+oIRkAWmq7RS3pusWIyXvuiL83JRJLZ4CU42ADWtkilNkYnIG/nQIr5muFkA9SsTkp04UYi8xWJ2dUfFdjescr2fjsB3oeBfmPAxERIEREBPR1XRcnFh9TjZM1DpkpGakkBlvupIO/iZfkdlW7KoMR7KCxavjZY/ecHJkVzZiooe5C32W/vqdM4/v4iUSvUhM2+mWPHkcCwAYrfpyAJANd6JkxW/fxr/KmMV1a3d9tV735+KuZiJAl+i5EV1bk4/qIDbIHKZD2yANfzIRLLl0dM5ESBERAREQE7ORARE1gavVXXcX+O9fMDgM5EQEREBN83JkxagLJNAAAWb0BoD4mIjQiXXqPQVYFqFJbGuP1ZNiO296+bkJR0HXb77v+P89pTk5tFVsceRYKSCR4FmhZrzQmeLiZrxF0Cx+ABZP4mI2j6v0UTgf6qj6r/Tbhpjlj6rYhfTiQKN+q6I8zwcmBWwWzLG1x9IGsSGysm8rBHgbN6xxceRqwNE7IA9ILefOtDydSnSqjNXI5VcW9QXI2FJQVY0WAF+LvxOny+WSSfX+olYrsbvveq/iu/wB5wTruTV+BQ0Brv4795vpuLN1XJVyIGTGlF+WPgTn5VKIiQU4cchnePnGr+1ycRARLdNyIuWfHnakL6iuLH9ra717eZGXBVOocKyB2CNRZQxCtj+3IdjVmrk613+3+f5uciNCIiQIiIHQJvn4WRmRlKspKspFEEGiD8gyc0gBIBNC9n2+ZRmIiQIiICJpmsDQFCid72TZs991qu0zAREQERECnT8ObqgIBYhbYhVFmrJPYfM11nTnj5H4yysVYrkjBlajVqw0ynwZGJrZ8czsejout5OEseNsSyNxnttXUq437gkTzxEl5WzAiV4ecqHAVTkuJyUMR6g1qT+1tVY3RI8w+T5PRNVkQNDwLrQjJgxlqqHe78+Nfxr+8zESDfC4VlJUMAQSpumo9jiQaPbRB+ZkzkpwKpZQ7FVJGRC5EC9kCxZA8WJd9DIQkEgGh3NaF9r9priQnIggUtm2AsWBQv9x32H/U1w8ZZsFYAE92YIDWxlZofmRjMFeAqLu7oYkVQbIbbWxjl281HUpi7DINTEZLeLUf3LYBo99gSYnI3rAlul58CTgrWrLTCwMlK5D/AHC7B8ESMRLncCJXqQgY/TLFNUWUKewuwCR3vzJRZgRESBERATfDylTkpo73/Io/2M31fUfUcuVVb8IoVRQrQHaRlvV6CIiQIiICIiAiIgIiICIns/SRwfVX/wDSeQcO8vpBS/Y1jlrvXfxLxm3B44nW767TkWZcCJTqOFkYq1WO9EHuL7jUnIEREBERA7NcdX6rr479td/mZrV39pyBpEJ0BZon7AWT9gCZwCa5SpPpBAoaJvwL3Q82ZxxRNNdHRF0a8i6Mo4ykEgiiNEe05OsxJsmydk+8E9tf/dyDXCgZgCwUE0WN0vycQTX8AzvDxhsrYLSk7vdf0igdmTiWWBE26ABSGBsWQAfSbIo2NmgDqxv3sDLe9Rg5EToMkFek6l+J15EanU2DQNfnUjPT+odYebkfkKopY2V40CIPhVXSj+JBFsgWBZqz2H8zV+pehmdE7yLRIsGjVjsfkfEzMhEr03TvyMERCznsqgkn+AO8mZcub6HIierj/T+VuJ+cITxIyoz+FZwSoP8AIVvxE42+B5YiJBvk4ytXWwDpge/vR0fg7mIiBbq+JUcqvIORR2dQwDa8BgD+RIxEt8hERIETSqTdDt3+JmXKEREgREQE6RORARKdRwMjYupVqBoijsAj8ggycBERApn6ccRok5bvYAo7qte3mTnQxoi9Hv8AMtw8fGU5CzkOAMFCWHs01tfpob7G5qTRnjRSrEvTCsVxvKzvd+mhMOte3YHRvuL/ADDqKFG7FkV2NkV86AP3mZAiIkCXHVv9P6WX+nnnj4yrG/xqOt4VR2VOQcig0HUMAw9wGAI+4kcTV1r3msvG2DkTWWq8XfYf8zMyKcGOS53hYyxrKr3V6uo6jHJsLws45VlV6utXUnEu9YEREg+h1H6ofqrzcCDp2VVA+kzrRVApYEsSCdk78zwEzkTfP/py53bTCducluPnpHTBTkVORHqXG9Kb0De/4EzB3ourbideRKyU2LRXH3VwQfuJEzkRtzAluLpXYWqMw7WFJ/4kxVGwb8b7fzrc1x87LpWYD4JEvH47/L+hOIm0QEMcgKFgG7bYFCh33e67TIxERA936b+oc3EOROLkKjlT6fIAQMlsMVN+LAnhiaZSO4I7H7EWP7TV5crJLeoMxL9bycbOTx8ZRPCl8yNb9VC9/EhJZlwJ0S55uQcWGZ+kzZ4ZaLKMQxW9GiRZ95IEAaOzYIoVWqo+/fx4+dWyDES/L09Ij5qcsvSCclxNeoVq/Ezw8OQY5KMVy2wF7Apfc7uvYH2j43cEpXk6hmVFJGKXjoD9xs2QLO/eSiZ0IiICIiBouaC+ASe3k0D/AMCZiICInYHJQ8zY4ZHAEsFs4gkAE12ugBfxJxARNOpBogg+xFTMBE07FiSTZPf5h3JNkknts32FD+0ozE6ROSWYEREBERAREQEREBERAREQNfUNY2cbur1Y0DXvszhNxEaOREQEREBERA2QuI2crNitAUMSDezeVivA73rERAREQEREBERATavQI3uux0QN7HndfiIl8DEREg6xJ7mciICIiBbrOqflduTkcvyMbZmNlj7kyMRLbvkIiJAiIgIiICIiB//Z";
  let planetIndex = 0;
  const [people, setPeople] = useState([]);
  const [person, setPerson] = useState([]);
  let [planets, setPlanets] = useState([]); 
  const [films, setFilms] = useState([]);
  const [loading, setLoading] = useState(true);
  function getSecondPart(str) {
    return str.split('=')[1];
}
  useEffect(() => {
    async function fetchPeople() {
     //console.log(window.placeholder);
     let url;
     let bool;
     if (window.location.href.includes('='))
        bool = true;
        else
        bool = false;
    //if (peopleBool === true)
       //url = 'https://swapi.co/api/people/';
       //else
       if (bool === true){
        let stringy = getSecondPart(window.location.href);
        url = 'https://swapi.co/api/people/?search='+stringy;  
         let stuff = [];
         do {
         let res = await fetch(url);
         let data = await res.json();
         
         url = data.next;
         stuff.push(...data.results);
         } while (url)
         setPeople(stuff);
        
         bool = false;
         setLoading(false);
       } 
       else 
       {
        
        url = 'https://swapi.co/api/people/' 
         let stuff = [];
         do {
         let res = await fetch(url);
         let data = await res.json();
         
         url = data.next;
         stuff.push(...data.results);
         } while (url)
         setPeople(stuff);
        
         
         setLoading(false);
       }
       
      }
      
     
    

    async function fetchPlanets() {
      let url;
      let bool;
      if (window.location.href.includes('='))
        bool = true;
        else
        bool = false;
        if (bool === true){
          let stringy = getSecondPart(window.location.href);
          url = 'https://swapi.co/api/planets/?search='+stringy;  
      
      let thing = [];
      do {
      let res = await fetch(url);
      let data = await res.json();
      url = data.next;
      //planets += data.results;
      thing.push(...data.results);
      
      
      } while (url)
      setPlanets(thing);
      setLoading(false);
    } 
    else
    {
      let url = 'https://swapi.co/api/planets/';
      let thing = [];
      do {
      let res = await fetch(url);
      let data = await res.json();
      url = data.next;
      //planets += data.results;
      thing.push(...data.results);
      
      
      } while (url)
      setPlanets(thing);
      setLoading(false);
    }

  }

    async function fetchFilms() {
      let url;
      let bool;
      if (window.location.href.includes('='))
        bool = true;
        else
        bool = false;
        if (bool === true){
          let stringy = getSecondPart(window.location.href);
          url = 'https://swapi.co/api/films/?search='+stringy; 

      let res = await fetch(url);
      let data = await res.json();
      setFilms(data.results);
      setLoading(false);
    }
    else
    {
      url = 'https://swapi.co/api/films/';
      let res = await fetch(url);
      let data = await res.json();
      setFilms(data.results);
      setLoading(false);
    }
  }

    fetchFilms();
    fetchPeople();
    fetchPlanets();
    
   
  }, [])
  //console.log('people', people);
  //console.log('planets', planets);
  return (
    <div style={{ backgroundImage : `url(${image_url})`, backgroundColor: "black" }}>
    <>
      <Router>
        <Navbar />
        <Container>
          { loading ? (
            <Dimmer active inverted>
              <Loader inverted>Oh my...</Loader>
            </Dimmer>
          ) : (
          <Switch>
            <Route exact path='/'>
              <Home data={films}/>
            </Route>
            <Route exact path='/people'>
              <People data={people}/>
              
            </Route>
            <Route exact path='/planets'>
              <Planets data={planets}/>             
            </Route>
          </Switch>)}
          
        </Container>
     </Router>
     
    </>
    </div>
  );
}

export default App;