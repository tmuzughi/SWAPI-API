import React from 'react';
import { Button, Label, Input, Form, TextArea, Search, Menu, Container } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
export default function Navbar() {
    function handleChange() {
        window.peopleBool = false;
    }
    function resetPage(){
        window.location.href = "http://localhost:3000/people/";
    }
    function resetPage1(){
        window.location.href = "http://localhost:3000/planets/";
    }
    function resetPage2(){
        window.location.href = "http://localhost:3000";
    }
    return (
        <div style={{backgroundColor: "black"}}>
        <Menu inverted style={{backgroundColor: "black"}}>
            <Container>
                <Link to='/'>
                    <Menu.Item name='films' onClick={resetPage2} style={{backgroundColor: "black", color: "gold"}}/>
                </Link>
                <Link to='/people' >
                     <Menu.Item name='characters' onClick={resetPage} style={{backgroundColor: "black", color: "gold"}}/>  
                     
                </Link>
                <Link to='/planets'>
                     <Menu.Item name='planets' onClick={resetPage1} style={{backgroundColor: "black", color: "gold"}}/>   
                </Link>
                     <form>                                          
                        <input type="text" name="search" style={{backgroundColor: "gold", color: "black"}}/>                  
                    <input type="submit" value="Search" onClick={handleChange} style={{backgroundColor: "black", color: "gold"}}/>}
                    </form>
                    
            </Container>
        </Menu>
        </div>
    );
}