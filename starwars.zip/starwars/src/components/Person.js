import React, {useState, useEffect } from 'react'

export default function Person({data}){
    let [humanoid, setHumanoid] = useState([]);
    const [loading, setLoading] = useState(true);

console.log(data)
    useEffect(() => {
async function fetchPerson() {
    let url = data;
    let res = null;
console.log(data)
    res = await fetch(url);
    data = await res.json();
    setHumanoid(data.name);
    window.someGuy = data.name;
    //console.log(humanoid);
    setLoading(false);
}
console.log(humanoid)
if (window.someGuy == null)
window.someGuy = "hi mom";
fetchPerson();
    }, []);
    return(
        <p>{window.someGuy}</p>
        
    );
}