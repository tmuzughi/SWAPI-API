import React, {useState, useEffect } from 'react';
import { render } from '@testing-library/react';


  
export default function WhichFilms ( { data } ) {
    


    const [films, setFilms] = useState([]); 
    const [films1, setFilms1] = useState([]); 
    const [films2, setFilms2] = useState([]); 
    const [films3, setFilms3] = useState([]); 
    const [films4, setFilms4] = useState([]); 
    const [films5, setFilms5] = useState([]); 
    const [films6, setFilms6] = useState([]); 
    const [loading, setLoading] = useState(true);
  
  let holdItHere = [];
  holdItHere.push(...data);
  let lengthNumber = holdItHere.length;
  
  //console.log(lengthNumber)
  

     
      useEffect(() => {
      
      async function fetchFilms( i ) {
        let url = holdItHere[i];
       let res = null;      
         res = await fetch(url);      
        let data = await res.json();
        if (i === 0)
        setFilms(data.title); 
        if (i === 1)
        setFilms1(data.title);
        if (i === 2)
        setFilms2(data.title); 
        if (i === 3)
        setFilms3(data.title);
        if (i === 4)
        setFilms4(data.title); 
        if (i === 5)
        setFilms5(data.title);
        if (i === 6)
        setFilms6(data.title);
        //console.log(data.title)
        setLoading(false)
        
        //console.log(window.filmy[0])     
        
      }
      for ( let i = 0; i < lengthNumber; i++){
        //console.log(holdItHere[i]); 
           
      fetchFilms( i );
      }
    }, [])
    return (
        <div>
        <p>{films}</p>
        <p>{films1}</p>
        <p>{films2}</p>
        <p>{films3}</p>
        <p>{films4}</p>
        <p>{films5}</p>
        <p>{films6}</p>
        </div>
      );
      
          
          

}