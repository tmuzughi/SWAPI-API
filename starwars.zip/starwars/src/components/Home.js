import React from 'react'
import { Card, Grid, Modal, Button } from 'semantic-ui-react';
import Whichperson from './Person';
import People from './People';

export default function Home({ data }) {
    return (
        <>
        <h1>Films</h1>
        <Grid columns={3}>
            {data.map((films, i) => {
                return (
                    <Grid.Column key={i}>
                        <Card style={{ backgroundColor: "black"}}>
                            <Card.Content>
                               <Card.Header><div style={{color: "gold"}}>{films.title}</div></Card.Header> 
                               <Card.Description>
                                   <div style={{color: "gold"}}>
                                   <strong>Episode</strong>
                                   <p>{films.episode_id}</p>
                                   <strong>Director</strong>
                                   <p>{films.director}</p>
                                   <strong>Release Date</strong>
                                   <p>{films.release_date}</p>
                                   <strong>Opening Crawl</strong>
                                   <p>{films.opening_crawl}</p>
                                   </div>
                               </Card.Description>
                               <Modal trigger={<Button style={{color: "black", backgroundColor: "gold"}}>More Info</Button>}>
                               <Modal.Description style={{backgroundColor: "black"}}>
                               
                               <div style={{color: "gold", textAlign: "center"}}>
                               <h1 style={{color: "gold"}}>{films.title}</h1>  
                                   <h3>Producer</h3>
                                   <p>{films.producer}</p>
                                   <h3>Characters</h3>
                                    <p>{films.characters.map(s=> (<><Whichperson data={s}/></>))}</p>
                                   
                               </div>
                               </Modal.Description>
                                   </Modal>
                            </Card.Content>
                        </Card>
                    </Grid.Column>
                )
            })}
        </Grid>

        
        </>
    )
}