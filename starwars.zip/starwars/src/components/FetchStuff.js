import React from 'react';

class FetchStuff extends React.Component {

state = {
    loading: true,
    planet: null
}

async componentDidMount(){
    const url = "swapi.co/api/planets/1";
    //const url = "http://swapi.co/api/people/1";
    const response = await fetch(url);
    const data = await response.json();
    this.setState({planet: data.results, loading: false})
    //console.log(data.results[0]);
}

    render() {
        return (
            <div>
        {this.state.planet.name}
        </div>
        );
            }
}
export default FetchStuff;