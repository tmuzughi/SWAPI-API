import React from 'react'
import { Card, Grid, Modal, Button } from 'semantic-ui-react';
import WhichFilms from '../components/WhichFilms';

export default function Planets({ data }) {
    return (
        <>
        <h1>Planets</h1>
        <Grid columns={3}>
            {data.map((planets, i) => {
                return (
                    
                    <Grid.Column key={i}>
                       
                        <Card style={{ backgroundColor: "black"}}>
                        
                            <Card.Content>
                               <Card.Header><div style={{color: "gold"}}>{planets.name}</div></Card.Header> 
                               
                               <Card.Description>
                               <div style={{color: "gold"}}>
                                   <strong>Climate</strong>
                                   <p>{planets.climate}</p>
                                   <strong>Terrain</strong>
                                   <p>{planets.terrain}</p>
                                   <strong>Population</strong>
                                   <p>{planets.population}</p>
                                   <strong>Films</strong>
                                    <WhichFilms data={planets.films}/>
                                    </div>
                               </Card.Description>
                               <Modal trigger={<Button style={{color: "black", backgroundColor: "gold"}}>More Info</Button>}>
                               <Modal.Description style={{backgroundColor: "black"}}>
                               <div style={{color: "gold", textAlign: "center"}}>
                               <h1 style={{color: "gold"}}>{planets.name}</h1>  
                                   <strong>Rotation Period</strong>
                                   <p>{planets.rotation_period}</p>
                                   <strong>Orbital Period</strong>
                                   <p>{planets.orbital_period}</p>
                                   <strong>Diameter</strong>
                                   <p>{planets.diameter}</p>
                                   <strong>Gravity</strong>
                                   <p>{planets.gravity}</p>
                                   <strong>Surface Water</strong>
                                   <p>{planets.surface_water}</p>
                                   
                               </div>
                               </Modal.Description>
                                   </Modal>
                            </Card.Content>
                        </Card>
                    </Grid.Column>
                )
            })}
            
        </Grid>
        
        </>
    )
}