import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ExampleFunction } from './components/example';
import  FetchStuff  from './components/FetchStuff';

import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

const Body = props => (
  <div>
    <p className="App-intro">{props.text}</p>
    <h1>Hi, I work.</h1>
  </div>
);

//<FetchStuff/>
export default function App() {
  
  return (
    

    <Router>
      <div>
        <nav>
          <ul>  
            <li>
              <Link to="/">Characters</Link>
            </li>
            <li>       
              <Link to="/films">Films</Link>
            </li>
            <li>        
              <Link to="/planets">Planets</Link>
            </li>
          </ul>
        </nav>

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        <Switch>
          <Route path="/films">
            <Films />
            <FetchStuff />
          </Route>
          <Route path="/planets">
            <Planets />
          </Route>
          <Route path="/">
            <Characters />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

function Characters() {
 
  return <h2>Characters</h2>;
}

function Films() {
  return <h2>Films</h2>;
}

function Planets() {
  return <h2>Planets</h2>;
}

//<FetchStuff/>
//export default App;
