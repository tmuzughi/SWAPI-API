import { Card, Grid} from 'semantic-ui-react';

import Homeworld from '../components/Homeworld';
import FetchStuff from '../components/FetchStuff';
import WhichFilms from '../components/WhichFilms';
import { render } from 'react-dom';
import Person from '../components/Person';
import React, {useState, useEffect } from 'react';
import { Alert } from 'reactstrap';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Container, Dimmer, Loader, Modal, Button } from 'semantic-ui-react';

let globalBool = false;
let arrayShelf;
let myColor = "black";
let image_url = "https://lh3.googleusercontent.com/proxy/nTnZE7Ce__oQ3uCry05xpe4o5ZgPgtEYjAYcparS0AIbNxdoHvMM0ZjNx9HzzMpWaUzRoUYRKPQFDT8UNK8LYXppglpG3EdjWK7WLKfmDQ";
 function myFunction( person ){
    
   window.myColor = "gold";
    //window.location.reload(false);
    return(
       null
    )

}


export default function People({ data }) {
    
    return (
        
        <div style={{ backgroundImage : `url(${image_url})` }}>
        <>
        <h1>Characters</h1>
        <Grid style={{color: "black"}}columns={3}>
            {data.map((people, i) => {
                
                return (
                    
                    <Grid.Column key={i}>
                        
                    
                        <Card style={{ backgroundColor: "black"}} >
                                    
                            <Card.Content >
                               <Card.Header><div style={{color: "gold"}}>{people.name}</div></Card.Header>
                               
                               <Card.Description >
                                   
                                   <strong style={{color: "gold"}}>Gender</strong>
                                   <p style={{color: "gold"}}>{people.gender}</p>
                                   <strong style={{color: "gold"}}>Height</strong>
                                   <p style={{color: "gold"}}>{people.height}</p>
                                   <strong style={{color: "gold"}}>Homeworld</strong>
                                      <div style={{color: "gold"}}>  <Homeworld data={people.homeworld}/>  </div>                               
                                   <strong style={{color: "gold"}}>Films</strong>                                  
                                    <div style={{color: "gold"}}><WhichFilms data={people.films}/> </div>
                                    
                               </Card.Description>
                               <Modal trigger={<Button style={{color: "black", backgroundColor: "gold"}}>More Info</Button>}>
                               <Modal.Description style={{backgroundColor: "black"}}>
                                   <div style={{textAlign: "center"}}>
                               <h1 style={{color: "gold"}}>{people.name}</h1>               
                                <strong style={{color: "gold"}}>Mass</strong>
                                <p style={{color: "gold"}}>{people.mass}</p>
                                <strong style={{color: "gold"}}>Hair Color</strong>
                                <p style={{color: "gold"}}>{people.hair_color}</p>
                                <strong style={{color: "gold"}}>Eye Color</strong>
                                <p style={{color: "gold"}}>{people.eye_color}</p>
                                <strong style={{color: "gold"}}>Birth Year</strong>
                                <p style={{color: "gold"}}>{people.birth_year}</p>
                                </div>
                                   </Modal.Description>
                                   </Modal>
                            </Card.Content>
                        </Card>
                        
                    </Grid.Column>
                    
                )
            })}
        </Grid>

        </>
        </div>
    )
}