import React, {useState, useEffect } from 'react';
import { render } from '@testing-library/react';



export default function Homeworld ( { data } ) {
  let [planets, setPlanets] = useState([]); 
  const [loading, setLoading] = useState(true);

      //let url = 'https://swapi.co/api/planets/8/';
      //let url = leopords;
      useEffect(() => {
      //console.log(url)
      async function fetchPlanet() {
        let url = data;
       let res = null;
       //console.log(url)
         res = await fetch(url);
        //console.log(res)
        data = await res.json();
        setPlanets(data.results);
        //console.log(data.name)
        window.homeBoy = data.name;
        //console.log(window.homeBoy)
        setLoading(false);
      }
      if (window.homeBoy == null)
        window.homeBoy = "Hi mom";
      
      fetchPlanet();
      
    }, [])
      
      return (
        <p>{window.homeBoy}</p>
      );
      

}